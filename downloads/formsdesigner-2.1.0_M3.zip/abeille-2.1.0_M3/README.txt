This is the README file for Abeille Forms Designer
Copyright 2004, JETA Software, Inc.
www.jetaware.com

By using Abeille, you agree to the licensing terms stated on the
Abeille Forms Designer download page at www.jetaware.com.


Installation
Unzip abeilleforms.zip into any directory.   abeilleforms.zip contains the following:
       1. README.txt
       2. designer.jar - the jar file for the application
       2. formsrt.jar - the forms runtime jar
       3. documentation/  - documentation directory

To run the application type (you must have the Sun JDK 1.4 installed):
      java -jar designer.jar

You can get support by emailing:  support@jetaware.com
If you have any other questions or comments feel free to contact us at:  info@jetaware.com


Thanks for your interest in JETA Software.



